// Creates the database schema. Safe to run multiple times (IF NOT EXISTS).
// Run manually with: npm run init-db
//
// UPGRADE NOTE: this file now also runs lightweight *migrations* for
// databases created by earlier versions of the app. SQLite's
// `CREATE TABLE IF NOT EXISTS` doesn't help once a table already exists with
// an older shape, so `migrateColumns()` below inspects each table with
// PRAGMA table_info and ALTERs in any columns that are missing. This lets
// upgrades run safely against a database that already has data in it.
const db = require('../config/database');

function init() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'admin',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      description TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS videos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      description TEXT DEFAULT '',
      embed_url TEXT NOT NULL,
      thumbnail TEXT DEFAULT '',
      thumbnail_srcset TEXT DEFAULT '',
      duration TEXT DEFAULT '',
      category_id INTEGER,
      tags TEXT DEFAULT '',
      views INTEGER NOT NULL DEFAULT 0,
      featured INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'published',
      meta_title TEXT DEFAULT '',
      meta_description TEXT DEFAULT '',
      publish_date TEXT NOT NULL DEFAULT (date('now')),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT DEFAULT ''
    );

    -- One row per playback start. Powers daily/weekly/monthly analytics and
    -- a recency-weighted trending algorithm, instead of only a lifetime
    -- 'views' counter that can't express "popular this week".
    CREATE TABLE IF NOT EXISTS video_view_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      video_id INTEGER NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_videos_category ON videos(category_id);
    CREATE INDEX IF NOT EXISTS idx_videos_featured ON videos(featured);
    CREATE INDEX IF NOT EXISTS idx_videos_slug ON videos(slug);
    CREATE INDEX IF NOT EXISTS idx_videos_status ON videos(status);
    CREATE INDEX IF NOT EXISTS idx_videos_publish_date ON videos(publish_date);
    CREATE INDEX IF NOT EXISTS idx_videos_views ON videos(views);
    CREATE INDEX IF NOT EXISTS idx_categories_slug ON categories(slug);
    CREATE INDEX IF NOT EXISTS idx_view_events_video ON video_view_events(video_id);
    CREATE INDEX IF NOT EXISTS idx_view_events_created ON video_view_events(created_at);
  `);

  migrateColumns();

  // Default site settings used across the SEO/meta partials
  const defaults = {
    site_tagline: 'Watch what moves you.',
    site_description: 'StreamFlix is a curated video streaming platform featuring hand-picked videos from creators across the web.',
    contact_email: 'contact@example.com'
  };
  const insertSetting = db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
  for (const [k, v] of Object.entries(defaults)) insertSetting.run(k, v);

  console.log('Database schema ready at database/streamflix.db');
}

// Adds columns that didn't exist in earlier releases of this schema.
// Safe to run every boot: it only ALTERs a column in if PRAGMA table_info
// doesn't already report it.
function migrateColumns() {
  const columnsOf = (table) => db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name);

  const videoColumns = columnsOf('videos');
  const addVideoColumn = (name, ddl) => {
    if (!videoColumns.includes(name)) {
      db.exec(`ALTER TABLE videos ADD COLUMN ${ddl}`);
      console.log(`Migrated videos: added column "${name}"`);
    }
  };
  // These cover installs created before status/scheduling/srcset existed.
  addVideoColumn('status', "status TEXT NOT NULL DEFAULT 'published'");
  addVideoColumn('thumbnail_srcset', "thumbnail_srcset TEXT DEFAULT ''");
}

init();
module.exports = init;
