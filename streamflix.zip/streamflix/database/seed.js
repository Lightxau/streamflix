// Seeds a starter admin account plus example categories & videos so the
// site isn't empty on first run. Run with: npm run seed
require('../database/init')(); // ensure schema exists first
const bcrypt = require('bcrypt');
const slugify = require('slugify');
const db = require('../config/database');
const config = require('../config/config');

function upsertAdmin() {
  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(config.adminUsername);
  if (existing) {
    console.log(`Admin user "${config.adminUsername}" already exists, skipping.`);
    return;
  }
  const hash = bcrypt.hashSync(config.adminPassword, 12);
  db.prepare('INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)')
    .run(config.adminUsername, hash, 'admin');
  console.log(`Created admin user "${config.adminUsername}". Remember to change the password!`);
}

function upsertCategory(name, description) {
  const slug = slugify(name, { lower: true, strict: true });
  const existing = db.prepare('SELECT id FROM categories WHERE slug = ?').get(slug);
  if (existing) return existing.id;
  const info = db.prepare('INSERT INTO categories (name, slug, description) VALUES (?, ?, ?)')
    .run(name, slug, description);
  return info.lastInsertRowid;
}

function upsertVideo(v) {
  const slug = slugify(v.title, { lower: true, strict: true });
  const existing = db.prepare('SELECT id FROM videos WHERE slug = ?').get(slug);
  if (existing) return;
  db.prepare(`
    INSERT INTO videos
      (title, slug, description, embed_url, thumbnail, duration, category_id, tags, views, featured, meta_title, meta_description, publish_date)
    VALUES (@title, @slug, @description, @embed_url, @thumbnail, @duration, @category_id, @tags, @views, @featured, @meta_title, @meta_description, @publish_date)
  `).run({ ...v, slug });
}

function seed() {
  upsertAdmin();

  const catTutorials = upsertCategory('Tutorials', 'Hands-on lessons and how-tos.');
  const catDocs = upsertCategory('Documentaries', 'Long-form nonfiction storytelling.');
  const catMusic = upsertCategory('Music', 'Live sessions, videos, and performances.');
  const catTech = upsertCategory('Technology', 'Product deep dives and tech explainers.');

  // NOTE: These are example embeds using YouTube's official embeddable
  // player (youtube.com/embed/...), which explicitly permits embedding.
  // Replace with your own licensed / permitted embeds in production.
  upsertVideo({
    title: 'Introduction to Modern JavaScript',
    description: 'A friendly walkthrough of modern JavaScript features for developers moving from older syntax.',
    embed_url: 'https://www.youtube.com/embed/hdI2bqOjy3c',
    thumbnail: '/images/placeholder-thumb.svg',
    duration: '12:34',
    category_id: catTutorials,
    tags: 'javascript,programming,tutorial',
    views: 1520,
    featured: 1,
    meta_title: 'Introduction to Modern JavaScript | StreamFlix',
    meta_description: 'A friendly walkthrough of modern JavaScript features.',
    publish_date: '2026-05-01'
  });
  upsertVideo({
    title: 'Building Responsive Layouts with CSS Grid',
    description: 'Learn how CSS Grid makes responsive design layout simpler and more powerful.',
    embed_url: 'https://www.youtube.com/embed/9zBsdzdE4sM',
    thumbnail: '/images/placeholder-thumb.svg',
    duration: '18:02',
    category_id: catTutorials,
    tags: 'css,grid,web design',
    views: 980,
    featured: 0,
    meta_title: 'Building Responsive Layouts with CSS Grid | StreamFlix',
    meta_description: 'Learn how CSS Grid makes responsive design simpler.',
    publish_date: '2026-05-10'
  });
  upsertVideo({
    title: 'The Ocean Beneath: A Nature Documentary',
    description: 'An exploration of deep-sea ecosystems and the creatures that call them home.',
    embed_url: 'https://www.youtube.com/embed/2Z4m4lnjxkY',
    thumbnail: '/images/placeholder-thumb.svg',
    duration: '44:10',
    category_id: catDocs,
    tags: 'nature,ocean,documentary',
    views: 5400,
    featured: 1,
    meta_title: 'The Ocean Beneath: A Nature Documentary | StreamFlix',
    meta_description: 'An exploration of deep-sea ecosystems.',
    publish_date: '2026-04-18'
  });
  upsertVideo({
    title: 'Acoustic Sessions: Live in the Studio',
    description: 'An intimate acoustic performance recorded live in a small studio setting.',
    embed_url: 'https://www.youtube.com/embed/lTRiuFIWV54',
    thumbnail: '/images/placeholder-thumb.svg',
    duration: '9:47',
    category_id: catMusic,
    tags: 'music,acoustic,live',
    views: 3210,
    featured: 0,
    meta_title: 'Acoustic Sessions: Live in the Studio | StreamFlix',
    meta_description: 'An intimate acoustic performance recorded live.',
    publish_date: '2026-06-02'
  });
  upsertVideo({
    title: 'Inside the Next-Gen Chip Factory',
    description: 'A behind-the-scenes look at how modern semiconductor fabrication plants operate.',
    embed_url: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    thumbnail: '/images/placeholder-thumb.svg',
    duration: '21:15',
    category_id: catTech,
    tags: 'technology,manufacturing,chips',
    views: 7600,
    featured: 1,
    meta_title: 'Inside the Next-Gen Chip Factory | StreamFlix',
    meta_description: 'A behind-the-scenes look at chip manufacturing.',
    publish_date: '2026-06-20'
  });

  console.log('Seed data inserted.');
}

seed();
