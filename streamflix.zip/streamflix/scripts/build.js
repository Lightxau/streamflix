// Minifies public/css/*.css and public/js/*.js into public/dist/, mirroring
// the same folder layout (css/style.css, js/main.js, etc). server.js checks
// for public/dist and, when NODE_ENV=production and the folder exists,
// serves minified files first before falling back to the original public/
// source — so running this step is optional but recommended for production.
//
// Run with: npm run build
const fs = require('fs');
const path = require('path');
const { minify: minifyJs } = require('terser');
const CleanCSS = require('clean-css');

const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const DIST_DIR = path.join(PUBLIC_DIR, 'dist');

async function build() {
  fs.rmSync(DIST_DIR, { recursive: true, force: true });
  fs.mkdirSync(path.join(DIST_DIR, 'css'), { recursive: true });
  fs.mkdirSync(path.join(DIST_DIR, 'js'), { recursive: true });

  await buildCss();
  await buildJs();

  console.log(`Production build written to ${path.relative(process.cwd(), DIST_DIR)}`);
}

async function buildCss() {
  const srcDir = path.join(PUBLIC_DIR, 'css');
  const files = fs.readdirSync(srcDir).filter((f) => f.endsWith('.css'));
  for (const file of files) {
    const input = fs.readFileSync(path.join(srcDir, file), 'utf8');
    const output = new CleanCSS({ level: 2 }).minify(input);
    if (output.errors.length) {
      console.error(`CSS minify errors in ${file}:`, output.errors);
      process.exitCode = 1;
      continue;
    }
    fs.writeFileSync(path.join(DIST_DIR, 'css', file), output.styles);
    console.log(`Minified css/${file} (${input.length} -> ${output.styles.length} bytes)`);
  }
}

async function buildJs() {
  const srcDir = path.join(PUBLIC_DIR, 'js');
  const files = fs.readdirSync(srcDir).filter((f) => f.endsWith('.js'));
  for (const file of files) {
    const input = fs.readFileSync(path.join(srcDir, file), 'utf8');
    const result = await minifyJs(input, { compress: true, mangle: true });
    if (result.error) {
      console.error(`JS minify error in ${file}:`, result.error);
      process.exitCode = 1;
      continue;
    }
    fs.writeFileSync(path.join(DIST_DIR, 'js', file), result.code);
    console.log(`Minified js/${file} (${input.length} -> ${result.code.length} bytes)`);
  }
}

build().catch((err) => {
  console.error('Build failed:', err);
  process.exit(1);
});
