// Generates PNG app icons from public/images/icons/icon-source.svg.
// Run with: npm run icons  (requires `npm install` to have installed sharp)
//
// SVG works fine as a manifest icon in Chrome/Edge/Firefox, but iOS Safari's
// "Add to Home Screen" and some manifest validators expect real PNGs, so
// this produces those from the same source artwork rather than hand-drawing
// a second version.
const path = require('path');
const sharp = require('sharp');

const SRC = path.join(__dirname, '..', 'public', 'images', 'icons', 'icon-source.svg');
const OUT_DIR = path.join(__dirname, '..', 'public', 'images', 'icons');

const targets = [
  { name: 'icon-192.png', size: 192 },
  { name: 'icon-512.png', size: 512 },
  { name: 'icon-maskable-192.png', size: 192, padding: true },
  { name: 'icon-maskable-512.png', size: 512, padding: true },
  { name: 'apple-touch-icon.png', size: 180 }
];

async function run() {
  for (const t of targets) {
    const pipeline = sharp(SRC).resize(t.size, t.size);
    await pipeline.png().toFile(path.join(OUT_DIR, t.name));
    console.log(`Generated ${t.name}`);
  }
  console.log('Done. Update public/manifest.json if you rename any of these files.');
}

run().catch((err) => {
  console.error('Icon generation failed:', err.message);
  console.error('Make sure `npm install` has completed (this script needs the "sharp" package).');
  process.exit(1);
});
