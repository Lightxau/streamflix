const express = require('express');
const router = express.Router();
const { generateSitemap, generateRobotsTxt, generateRssFeed } = require('../utils/sitemap');

// Generated fresh on every request directly from the current database
// contents — there's no separate "regenerate the sitemap" step or cache to
// go stale, so newly added/deleted videos are reflected immediately.
router.get('/sitemap.xml', (req, res) => {
  res.type('application/xml').send(generateSitemap());
});

router.get('/robots.txt', (req, res) => {
  res.type('text/plain').send(generateRobotsTxt());
});

// UPGRADE: RSS feed of recently published videos.
router.get('/rss.xml', (req, res) => {
  res.type('application/rss+xml').send(generateRssFeed());
});

module.exports = router;
