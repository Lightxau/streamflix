const express = require('express');
const router = express.Router();
const videoController = require('../controllers/videoController');

router.get('/', videoController.home);
router.get('/categories', videoController.categoriesIndex);
router.get('/category/:slug', videoController.categoryShow);
router.get('/video/:slug', videoController.videoDetail);

module.exports = router;
