const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { requireAuth } = require('../middleware/auth');
const upload = require('../middleware/upload');
const { videoValidationRules, categoryValidationRules } = require('../middleware/validation');

router.use(requireAuth);

router.get('/', adminController.dashboard);

// Videos
router.get('/videos', adminController.videosList);
router.get('/videos/new', adminController.newVideoForm);
router.post('/videos/bulk', adminController.bulkVideoAction);
router.post('/videos', upload.single('thumbnail'), videoValidationRules, adminController.createVideo);
router.get('/videos/:id/edit', adminController.editVideoForm);
router.post('/videos/:id', upload.single('thumbnail'), videoValidationRules, adminController.updateVideo);
router.post('/videos/:id/delete', adminController.deleteVideo);

// Categories
router.get('/categories', adminController.categoriesList);
router.post('/categories', categoryValidationRules, adminController.createCategory);
router.post('/categories/:id', categoryValidationRules, adminController.updateCategory);
router.post('/categories/:id/delete', adminController.deleteCategory);

// Settings
router.get('/settings', adminController.settingsForm);
router.post('/settings', adminController.updateSettings);

module.exports = router;
