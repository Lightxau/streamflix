const express = require('express');
const router = express.Router();
const searchController = require('../controllers/searchController');

router.get('/search', searchController.searchPage);
router.get('/api/search-suggestions', searchController.suggestions);
router.get('/api/videos', searchController.videosApi);

module.exports = router;
