const express = require('express');
const router = express.Router();
const pageController = require('../controllers/pageController');

router.get('/about', pageController.about);
router.get('/contact', pageController.contact);
router.post('/contact', pageController.contactSubmit);
router.get('/privacy-policy', pageController.privacy);
router.get('/terms-of-service', pageController.terms);
router.get('/dmca', pageController.dmca);

module.exports = router;
