const express = require('express');
const router = express.Router();
const userFeatures = require('../controllers/userFeaturesController');

router.get('/favorites', userFeatures.favoritesPage);
router.get('/history', userFeatures.historyPage);
router.get('/api/videos-by-slugs', userFeatures.videosBySlugs);

module.exports = router;
