const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { redirectIfAuthed } = require('../middleware/auth');
const { loginLimiter } = require('../middleware/security');

router.get('/login', redirectIfAuthed, authController.showLogin);
router.post('/login', loginLimiter, redirectIfAuthed, authController.validators, authController.handleLogin);
router.post('/logout', authController.handleLogout);

module.exports = router;
