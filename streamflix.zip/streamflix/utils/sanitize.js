const xss = require('xss');

// Strips dangerous tags/attributes from user-entered text (titles,
// descriptions, tags) before it is stored or rendered. EJS already
// HTML-escapes by default with <%= %>, this is defense-in-depth for
// data that might be reused in feeds, JSON-LD, or attributes.
function clean(value) {
  if (typeof value !== 'string') return value;
  return xss(value.trim(), { whiteList: {}, stripIgnoreTag: true, stripIgnoreTagBody: ['script', 'style'] });
}

function cleanFields(obj, fields) {
  const result = { ...obj };
  for (const f of fields) {
    if (result[f] !== undefined) result[f] = clean(result[f]);
  }
  return result;
}

module.exports = { clean, cleanFields };
