const path = require('path');
const fs = require('fs');
const sharp = require('sharp');

const THUMB_DIR = path.join(__dirname, '..', 'uploads', 'thumbnails');
const SIZES = [320, 640];

// Takes the path to a just-uploaded image (any of jpeg/png/webp, see
// middleware/upload.js's fileFilter) and produces resized WebP variants next
// to it. Returns the public URL of the largest variant (used as the primary
// `thumbnail`) plus a ready-to-use `srcset` string for <img srcset>.
//
// If sharp isn't installed yet (e.g. `npm install` hasn't been re-run after
// this upgrade), we fall back to serving the original upload untouched
// rather than crashing the request — see the try/catch in the caller.
async function optimizeThumbnail(uploadedFilePath, filenameBase) {
  const variants = [];

  for (const width of SIZES) {
    const outName = `${filenameBase}-${width}.webp`;
    const outPath = path.join(THUMB_DIR, outName);
    await sharp(uploadedFilePath)
      .resize({ width, withoutEnlargement: true })
      .webp({ quality: 78 })
      .toFile(outPath);
    variants.push({ width, url: `/uploads/thumbnails/${outName}` });
  }

  // The original (non-resized) upload is no longer needed once we have the
  // optimized variants — remove it to save disk space.
  fs.unlink(uploadedFilePath, () => {});

  const largest = variants[variants.length - 1];
  const srcset = variants.map((v) => `${v.url} ${v.width}w`).join(', ');
  return { thumbnail: largest.url, srcset };
}

module.exports = { optimizeThumbnail };
