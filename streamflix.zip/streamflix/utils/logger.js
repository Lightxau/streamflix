const fs = require('fs');
const path = require('path');

const LOG_DIR = path.join(__dirname, '..', 'logs');
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });

// Rotating-by-restart access log stream for morgan in production. (For real
// rotation by size/date, point this at a tool like `logrotate` on the VPS,
// or swap in the `rotating-file-stream` package — kept dependency-free here.)
const accessLogStream = fs.createWriteStream(path.join(LOG_DIR, 'access.log'), { flags: 'a' });

function logError(err, context = {}) {
  const entry = {
    time: new Date().toISOString(),
    message: err && err.message,
    stack: err && err.stack,
    ...context
  };
  fs.appendFile(path.join(LOG_DIR, 'error.log'), `${JSON.stringify(entry)}\n`, () => {});
  // Still surface it in the console/process manager (pm2, docker logs, etc.)
  console.error(entry.time, entry.message);
}

module.exports = { accessLogStream, logError, LOG_DIR };
