const config = require('../config/config');
const Video = require('../models/Video');
const Category = require('../models/Category');

function urlTag(loc, lastmod, priority = '0.7', imageLoc = null) {
  const imageTag = imageLoc
    ? `\n    <image:image>\n      <image:loc>${imageLoc}</image:loc>\n    </image:image>`
    : '';
  return `  <url>\n    <loc>${loc}</loc>\n${lastmod ? `    <lastmod>${lastmod}</lastmod>\n` : ''}    <priority>${priority}</priority>${imageTag}\n  </url>`;
}

function absoluteImageUrl(thumbnailPath) {
  if (!thumbnailPath) return null;
  return thumbnailPath.startsWith('http') ? thumbnailPath : `${config.siteUrl}${thumbnailPath}`;
}

function generateSitemap() {
  const staticPages = [
    { path: '/', priority: '1.0' },
    { path: '/categories', priority: '0.8' },
    { path: '/about', priority: '0.5' },
    { path: '/contact', priority: '0.5' },
    { path: '/privacy-policy', priority: '0.3' },
    { path: '/terms-of-service', priority: '0.3' },
    { path: '/dmca', priority: '0.3' }
  ];

  // visibility: 'public' (the default) ensures drafts/scheduled videos never
  // appear in the sitemap that gets submitted to search engines.
  const { rows: videos } = Video.list({ perPage: 5000, page: 1 });
  const categories = Category.all();

  const urls = [
    ...staticPages.map((p) => urlTag(`${config.siteUrl}${p.path}`, null, p.priority)),
    ...categories.map((c) => urlTag(`${config.siteUrl}/category/${c.slug}`, null, '0.6')),
    // UPGRADE: each video URL now also emits an <image:image> entry (the
    // sitemap "Image Sitemap" extension), which helps thumbnails surface in
    // Google Images / video-rich search results.
    ...videos.map((v) => urlTag(
      `${config.siteUrl}/video/${v.slug}`,
      v.updated_at ? v.updated_at.slice(0, 10) : null,
      '0.8',
      absoluteImageUrl(v.thumbnail)
    ))
  ];

  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">\n${urls.join('\n')}\n</urlset>`;
}

function generateRobotsTxt() {
  return `User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /login\nDisallow: /api/\n\nSitemap: ${config.siteUrl}/sitemap.xml`;
}

// RSS 2.0 feed of the most recently published videos — lets subscribers and
// aggregators pick up new uploads without polling the site.
function generateRssFeed(limit = 30) {
  const { rows: videos } = Video.list({ perPage: limit, page: 1, sort: 'newest' });
  const items = videos.map((v) => `
    <item>
      <title><![CDATA[${v.title}]]></title>
      <link>${config.siteUrl}/video/${v.slug}</link>
      <guid isPermaLink="true">${config.siteUrl}/video/${v.slug}</guid>
      <pubDate>${new Date(v.publish_date).toUTCString()}</pubDate>
      <description><![CDATA[${v.description || ''}]]></description>
      ${v.category_name ? `<category><![CDATA[${v.category_name}]]></category>` : ''}
    </item>`).join('');

  return `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
  <channel>
    <title>${config.siteName}</title>
    <link>${config.siteUrl}</link>
    <description>Recently published videos on ${config.siteName}</description>
    <language>en-us</language>
    <lastBuildDate>${new Date().toUTCString()}</lastBuildDate>${items}
  </channel>
</rss>`;
}

module.exports = { generateSitemap, generateRobotsTxt, generateRssFeed };
