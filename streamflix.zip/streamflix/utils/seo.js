const config = require('../config/config');

// Builds the standard "seo" object every view expects (title, description,
// canonical URL, OG/Twitter tags). Pages spread sensible defaults and
// override only what's page-specific.
function buildSeo({ title, description, path = '/', image = null, type = 'website', robots = 'index, follow' }) {
  const canonical = `${config.siteUrl}${path}`;
  return {
    title,
    description,
    canonical,
    image: image || `${config.siteUrl}/images/og-default.svg`,
    type,
    robots,
    siteName: config.siteName
  };
}

// JSON-LD structured data for a video detail page using schema.org VideoObject
function videoJsonLd(video, path) {
  return {
    '@context': 'https://schema.org',
    '@type': 'VideoObject',
    name: video.title,
    description: video.description,
    thumbnailUrl: [`${config.siteUrl}${video.thumbnail}`],
    uploadDate: video.publish_date,
    contentUrl: video.embed_url,
    embedUrl: video.embed_url,
    interactionStatistic: {
      '@type': 'InteractionCounter',
      interactionType: 'https://schema.org/WatchAction',
      userInteractionCount: video.views
    },
    ...(video.duration ? { duration: toIsoDuration(video.duration) } : {}),
    url: `${config.siteUrl}${path}`
  };
}

// Converts "MM:SS" or "HH:MM:SS" into ISO 8601 duration (e.g. PT12M34S)
function toIsoDuration(duration) {
  const parts = String(duration).split(':').map((n) => parseInt(n, 10)).filter((n) => !Number.isNaN(n));
  if (!parts.length) return undefined;
  let h = 0, m = 0, s = 0;
  if (parts.length === 3) [h, m, s] = parts;
  else if (parts.length === 2) [m, s] = parts;
  else [s] = parts;
  return `PT${h ? h + 'H' : ''}${m ? m + 'M' : ''}${s ? s + 'S' : ''}` || 'PT0S';
}

function breadcrumbJsonLd(items) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: item.name,
      item: `${config.siteUrl}${item.path}`
    }))
  };
}

// Organization schema — identifies the publisher/brand. Included on every
// page (see views/partials/head.ejs) since Google recommends it site-wide,
// not just on the homepage.
function organizationJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: config.siteName,
    url: config.siteUrl,
    logo: `${config.siteUrl}/images/og-default.svg`
  };
}

// WebSite schema with a SearchAction — this is what enables Google's
// "sitelinks search box" for the site in search results.
function websiteJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: config.siteName,
    url: config.siteUrl,
    potentialAction: {
      '@type': 'SearchAction',
      target: `${config.siteUrl}/search?q={search_term_string}`,
      'query-input': 'required name=search_term_string'
    }
  };
}

module.exports = { buildSeo, videoJsonLd, breadcrumbJsonLd, toIsoDuration, organizationJsonLd, websiteJsonLd };
