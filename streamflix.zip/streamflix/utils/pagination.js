// Returns a function that, given a page number, returns a query string like
// "?sort=popular&page=3" while preserving the current request's other params.
function makePageQueryBuilder(currentQuery) {
  return function buildPageQuery(page) {
    const params = new URLSearchParams(currentQuery);
    params.set('page', page);
    return `?${params.toString()}`;
  };
}

module.exports = { makePageQueryBuilder };
