require('dotenv').config();

module.exports = {
  port: process.env.PORT || 3000,
  env: process.env.NODE_ENV || 'development',
  siteUrl: process.env.SITE_URL || 'http://localhost:3000',
  siteName: process.env.SITE_NAME || 'StreamFlix',
  sessionSecret: process.env.SESSION_SECRET || 'dev_only_secret_change_me',
  adminUsername: process.env.ADMIN_USERNAME || 'admin',
  adminPassword: process.env.ADMIN_PASSWORD || 'ChangeMe123!',
  rateLimitWindowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS, 10) || 15 * 60 * 1000,
  rateLimitMax: parseInt(process.env.RATE_LIMIT_MAX, 10) || 200,
  googleSiteVerification: process.env.GOOGLE_SITE_VERIFICATION || '',
  googleAnalyticsId: process.env.GOOGLE_ANALYTICS_ID || '',
  googleTagManagerId: process.env.GOOGLE_TAG_MANAGER_ID || ''
};
