const path = require('path');
const Database = require('better-sqlite3');

const DB_PATH = path.join(__dirname, '..', 'database', 'streamflix.db');

// A single shared connection. better-sqlite3 is synchronous, which keeps
// the model layer simple and avoids callback/promise boilerplate.
const db = new Database(DB_PATH);

// Sensible production pragmas
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

module.exports = db;
