const fs = require('fs');
const path = require('path');
const config = require('../config/config');
const Video = require('../models/Video');
const Category = require('../models/Category');
const Setting = require('../models/Setting');
const { buildSeo } = require('../utils/seo');
const { validationResult } = require('../middleware/validation');
const { cleanFields } = require('../utils/sanitize');
const { makePageQueryBuilder } = require('../utils/pagination');
const { optimizeThumbnail } = require('../utils/imageOptimizer');
const { logError } = require('../utils/logger');

const adminSeo = (title) => buildSeo({ title: `${title} | Admin | ${config.siteName}`, description: '', path: '/admin', robots: 'noindex, nofollow' });

// A video is "Scheduled" (as opposed to plain "Published") when its status
// is published but the publish_date hasn't arrived yet — see the comment on
// PUBLIC_VISIBLE_SQL in models/Video.js for why that's how scheduling works.
function describeStatus(video) {
  if (video.status === 'draft') return 'draft';
  if (video.publish_date > new Date().toISOString().slice(0, 10)) return 'scheduled';
  return 'published';
}

// Sums the size of every file in uploads/thumbnails — a simple, dependency-free
// "storage usage" figure for the dashboard. Fine at the scale of a single-server
// SQLite app; swap for a proper disk-usage query if uploads move to S3/etc.
function getStorageUsageBytes() {
  const dir = path.join(__dirname, '..', 'uploads', 'thumbnails');
  try {
    return fs.readdirSync(dir).reduce((total, file) => {
      if (file === '.gitkeep') return total;
      try {
        return total + fs.statSync(path.join(dir, file)).size;
      } catch (e) {
        return total;
      }
    }, 0);
  } catch (e) {
    return 0;
  }
}

function formatBytes(bytes) {
  if (!bytes) return '0 MB';
  const mb = bytes / (1024 * 1024);
  if (mb < 1024) return `${mb.toFixed(1)} MB`;
  return `${(mb / 1024).toFixed(2)} GB`;
}

exports.dashboard = (req, res) => {
  const counts = Video.counts();
  const categories = Category.all();
  const topVideos = Video.topByViews(5);
  const recentlyUploaded = Video.recentlyUploaded(5);

  res.render('admin/dashboard', {
    seo: adminSeo('Dashboard'),
    counts,
    categoryCount: categories.length,
    topVideos,
    recentlyUploaded,
    // UPGRADE: real analytics, driven by the video_view_events log table
    // (see database/init.js + models/Video.js) instead of only a lifetime
    // views counter.
    dailyViews: Video.dailyViews(14),
    weeklyViews: Video.weeklyViews(8),
    monthlyViews: Video.monthlyViews(6),
    topCategories: Video.topCategories(6),
    storageUsage: formatBytes(getStorageUsageBytes())
  });
};

// ----- Videos -----

exports.videosList = (req, res) => {
  const page = parseInt(req.query.page, 10) || 1;
  const q = (req.query.q || '').trim() || null;
  const status = req.query.status || null;
  const sort = req.query.sort || 'newest';
  // visibility: 'all' — admins need to see drafts/scheduled videos too, not
  // just what's publicly visible.
  const result = Video.list({ page, perPage: 15, sort, q, status, visibility: 'all' });
  const rowsWithStatus = result.rows.map((v) => ({ ...v, displayStatus: describeStatus(v) }));

  res.render('admin/videos-list', {
    seo: adminSeo('Manage Videos'),
    result: { ...result, rows: rowsWithStatus },
    q: q || '',
    status: status || '',
    sort,
    baseUrl: '/admin/videos',
    buildPageQuery: makePageQueryBuilder(req.query),
    categories: Category.all()
  });
};

exports.newVideoForm = (req, res) => {
  const categories = Category.all();
  res.render('admin/video-form', { seo: adminSeo('Add Video'), categories, video: null, errors: [] });
};

// Both createVideo and updateVideo are `async` because optimizing the
// uploaded thumbnail (resize + WebP conversion via sharp) is an async
// operation. Express supports async route handlers directly; any thrown
// error is caught below and forwarded to the centralized error handler so a
// broken image doesn't leave the request hanging.
exports.createVideo = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    const categories = Category.all();

    if (!errors.isEmpty()) {
      return res.status(400).render('admin/video-form', {
        seo: adminSeo('Add Video'), categories, video: req.body, errors: errors.array()
      });
    }

    const data = cleanFields(req.body, ['title', 'description', 'tags', 'meta_title', 'meta_description']);
    let thumbnail = data.thumbnail_url || '/images/placeholder-thumb.svg';
    let thumbnail_srcset = '';

    if (req.file) {
      try {
        const base = path.parse(req.file.filename).name;
        const optimized = await optimizeThumbnail(req.file.path, base);
        thumbnail = optimized.thumbnail;
        thumbnail_srcset = optimized.srcset;
      } catch (imgErr) {
        // Don't fail the whole video creation just because image
        // optimization hiccuped (e.g. sharp not installed yet) — fall back
        // to serving the untouched upload and log it for follow-up.
        logError(imgErr, { context: 'thumbnail optimization', file: req.file.filename });
        thumbnail = `/uploads/thumbnails/${req.file.filename}`;
      }
    }

    const status = req.body.status === 'draft' ? 'draft' : 'published';

    const video = Video.create({
      title: data.title,
      description: data.description || '',
      embed_url: data.embed_url,
      thumbnail,
      thumbnail_srcset,
      duration: data.duration || '',
      category_id: data.category_id || null,
      tags: data.tags || '',
      featured: data.featured === 'on' || data.featured === '1' ? 1 : 0,
      status,
      meta_title: data.meta_title || '',
      meta_description: data.meta_description || '',
      publish_date: data.publish_date || new Date().toISOString().slice(0, 10)
    });

    req.session.flash = { type: 'success', message: `"${video.title}" was saved as ${describeStatus(video)}.` };
    res.redirect('/admin/videos');
  } catch (err) {
    next(err);
  }
};

exports.editVideoForm = (req, res, next) => {
  const video = Video.findById(req.params.id);
  if (!video) return next();
  const categories = Category.all();
  res.render('admin/video-form', { seo: adminSeo('Edit Video'), categories, video: { ...video, displayStatus: describeStatus(video) }, errors: [] });
};

exports.updateVideo = async (req, res, next) => {
  try {
    const existing = Video.findById(req.params.id);
    if (!existing) return next();

    const errors = validationResult(req);
    const categories = Category.all();
    if (!errors.isEmpty()) {
      return res.status(400).render('admin/video-form', {
        seo: adminSeo('Edit Video'), categories, video: { ...existing, ...req.body }, errors: errors.array()
      });
    }

    const data = cleanFields(req.body, ['title', 'description', 'tags', 'meta_title', 'meta_description']);
    let thumbnail = data.thumbnail_url || existing.thumbnail;
    let thumbnail_srcset = existing.thumbnail_srcset || '';

    if (req.file) {
      try {
        const base = path.parse(req.file.filename).name;
        const optimized = await optimizeThumbnail(req.file.path, base);
        thumbnail = optimized.thumbnail;
        thumbnail_srcset = optimized.srcset;
      } catch (imgErr) {
        logError(imgErr, { context: 'thumbnail optimization', file: req.file.filename });
        thumbnail = `/uploads/thumbnails/${req.file.filename}`;
      }
    }

    const status = req.body.status === 'draft' ? 'draft' : 'published';

    const video = Video.update(req.params.id, {
      title: data.title,
      description: data.description || '',
      embed_url: data.embed_url,
      thumbnail,
      thumbnail_srcset,
      duration: data.duration || '',
      category_id: data.category_id || null,
      tags: data.tags || '',
      featured: data.featured === 'on' || data.featured === '1' ? 1 : 0,
      status,
      meta_title: data.meta_title || '',
      meta_description: data.meta_description || '',
      publish_date: data.publish_date || existing.publish_date
    });

    req.session.flash = { type: 'success', message: `"${video.title}" was updated (${describeStatus(video)}).` };
    res.redirect('/admin/videos');
  } catch (err) {
    next(err);
  }
};

exports.deleteVideo = (req, res) => {
  const video = Video.findById(req.params.id);
  if (video) {
    Video.delete(req.params.id);
    req.session.flash = { type: 'success', message: `"${video.title}" was deleted.` };
  }
  res.redirect('/admin/videos');
};

// UPGRADE: bulk actions — select multiple videos in the admin table and
// delete, re-categorize, feature/unfeature, or change status in one request.
exports.bulkVideoAction = (req, res) => {
  const ids = [].concat(req.body.video_ids || []).map((id) => parseInt(id, 10)).filter(Boolean);
  const action = req.body.bulk_action;

  if (!ids.length) {
    req.session.flash = { type: 'error', message: 'No videos were selected.' };
    return res.redirect('/admin/videos');
  }

  let message = '';
  switch (action) {
    case 'delete':
      Video.bulkDelete(ids);
      message = `Deleted ${ids.length} video${ids.length === 1 ? '' : 's'}.`;
      break;
    case 'feature':
      Video.bulkSetFeatured(ids, true);
      message = `Featured ${ids.length} video${ids.length === 1 ? '' : 's'}.`;
      break;
    case 'unfeature':
      Video.bulkSetFeatured(ids, false);
      message = `Unfeatured ${ids.length} video${ids.length === 1 ? '' : 's'}.`;
      break;
    case 'publish':
      Video.bulkSetStatus(ids, 'published');
      message = `Published ${ids.length} video${ids.length === 1 ? '' : 's'}.`;
      break;
    case 'draft':
      Video.bulkSetStatus(ids, 'draft');
      message = `Moved ${ids.length} video${ids.length === 1 ? '' : 's'} to drafts.`;
      break;
    case 'set_category': {
      const categoryId = req.body.bulk_category_id ? parseInt(req.body.bulk_category_id, 10) : null;
      Video.bulkSetCategory(ids, categoryId);
      message = `Updated category for ${ids.length} video${ids.length === 1 ? '' : 's'}.`;
      break;
    }
    default:
      req.session.flash = { type: 'error', message: 'Unknown bulk action.' };
      return res.redirect('/admin/videos');
  }

  req.session.flash = { type: 'success', message };
  res.redirect('/admin/videos');
};

// ----- Categories -----

exports.categoriesList = (req, res) => {
  res.render('admin/categories-list', { seo: adminSeo('Manage Categories'), categories: Category.all() });
};

exports.createCategory = (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    req.session.flash = { type: 'error', message: errors.array()[0].msg };
    return res.redirect('/admin/categories');
  }
  const data = cleanFields(req.body, ['name', 'description']);

  // UPGRADE (bugfix/code review): previously a duplicate category name would
  // hit the database's UNIQUE constraint and throw an unhandled SQLite error,
  // producing a generic 500 page. Now it's checked up front with a clear message.
  if (Category.findByName(data.name)) {
    req.session.flash = { type: 'error', message: `A category named "${data.name}" already exists.` };
    return res.redirect('/admin/categories');
  }

  Category.create({ name: data.name, description: data.description || '' });
  req.session.flash = { type: 'success', message: `Category "${data.name}" created.` };
  res.redirect('/admin/categories');
};

exports.updateCategory = (req, res, next) => {
  const category = Category.findById(req.params.id);
  if (!category) return next();
  const data = cleanFields(req.body, ['name', 'description']);

  const duplicate = Category.findByName(data.name);
  if (duplicate && duplicate.id !== category.id) {
    req.session.flash = { type: 'error', message: `A category named "${data.name}" already exists.` };
    return res.redirect('/admin/categories');
  }

  Category.update(req.params.id, { name: data.name, description: data.description || '' });
  req.session.flash = { type: 'success', message: 'Category updated.' };
  res.redirect('/admin/categories');
};

exports.deleteCategory = (req, res) => {
  Category.delete(req.params.id);
  req.session.flash = { type: 'success', message: 'Category deleted.' };
  res.redirect('/admin/categories');
};

// ----- Settings -----

exports.settingsForm = (req, res) => {
  res.render('admin/settings', { seo: adminSeo('Site Settings'), settings: Setting.all() });
};

exports.updateSettings = (req, res) => {
  const data = cleanFields(req.body, ['site_tagline', 'site_description', 'contact_email']);
  Setting.set('site_tagline', data.site_tagline || '');
  Setting.set('site_description', data.site_description || '');
  Setting.set('contact_email', data.contact_email || '');
  req.session.flash = { type: 'success', message: 'Settings saved.' };
  res.redirect('/admin/settings');
};
