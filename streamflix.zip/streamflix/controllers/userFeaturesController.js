const config = require('../config/config');
const Video = require('../models/Video');
const { buildSeo } = require('../utils/seo');

// StreamFlix has no visitor accounts (only an admin login), so "Continue
// Watching", "Recently Watched", and "Favorites" are implemented client-side
// with localStorage (see public/js/history.js) rather than a server-side
// per-user table. These two routes just render the page shells; the actual
// list is populated in the browser, which then calls the API route below to
// turn a list of slugs into real video cards.

exports.favoritesPage = (req, res) => {
  res.render('favorites', {
    seo: buildSeo({
      title: `Your Favorites | ${config.siteName}`,
      description: 'Videos you have favorited on this device.',
      path: '/favorites',
      robots: 'noindex, nofollow'
    })
  });
};

exports.historyPage = (req, res) => {
  res.render('history', {
    seo: buildSeo({
      title: `Watch History | ${config.siteName}`,
      description: 'Videos you have recently opened on this device.',
      path: '/history',
      robots: 'noindex, nofollow'
    })
  });
};

// GET /api/videos-by-slugs?slugs=a,b,c
// Returns lightweight, public-only video data for a client-provided list of
// slugs, preserving the order the client asked for so "most recent first"
// ordering (which only the browser's localStorage knows) is respected.
exports.videosBySlugs = (req, res) => {
  const slugs = (req.query.slugs || '').split(',').map((s) => s.trim()).filter(Boolean).slice(0, 60);
  if (!slugs.length) return res.json({ results: [] });

  const found = new Map();
  slugs.forEach((slug) => {
    const video = Video.findBySlug(slug);
    if (video) found.set(slug, video);
  });

  const results = slugs
    .filter((slug) => found.has(slug))
    .map((slug) => {
      const v = found.get(slug);
      return {
        title: v.title,
        slug: v.slug,
        thumbnail: v.thumbnail || '/images/placeholder-thumb.svg',
        thumbnail_srcset: v.thumbnail_srcset || '',
        duration: v.duration,
        views: v.views,
        category_name: v.category_name,
        category_slug: v.category_slug,
        featured: v.featured
      };
    });

  res.json({ results });
};
