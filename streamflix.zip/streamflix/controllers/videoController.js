const config = require('../config/config');
const Video = require('../models/Video');
const Category = require('../models/Category');
const { buildSeo, videoJsonLd, breadcrumbJsonLd } = require('../utils/seo');
const { makePageQueryBuilder } = require('../utils/pagination');

exports.home = (req, res) => {
  const featured = Video.featured(8);
  const trending = Video.trending(12);
  const popularWeek = Video.popularThisWeek(8);
  const recent = Video.recent(12);
  const categories = Category.all().slice(0, 8);

  res.render('home', {
    seo: buildSeo({
      title: `${config.siteName} — ${config.siteName === 'StreamFlix' ? 'Watch what moves you.' : 'Home'}`,
      description: 'Discover featured, trending, and recently added videos, all hand-picked and embedded from platforms that allow it.',
      path: '/'
    }),
    hero: featured[0] || trending[0] || null,
    featured,
    trending,
    popularWeek,
    recent,
    categories
  });
};

exports.videoDetail = (req, res, next) => {
  const video = Video.findBySlug(req.params.slug);
  if (!video) return next();

  Video.incrementViews(video.id);
  video.views += 1;

  const related = Video.related(video, 8);
  const tags = (video.tags || '').split(',').map((t) => t.trim()).filter(Boolean);
  const path = `/video/${video.slug}`;

  res.render('video-detail', {
    seo: buildSeo({
      title: video.meta_title || `${video.title} | ${config.siteName}`,
      description: video.meta_description || video.description.slice(0, 155),
      path,
      image: video.thumbnail,
      type: 'video.other'
    }),
    video,
    tags,
    related,
    jsonLd: videoJsonLd(video, path),
    breadcrumbJsonLd: breadcrumbJsonLd([
      { name: 'Home', path: '/' },
      ...(video.category_slug ? [{ name: video.category_name, path: `/category/${video.category_slug}` }] : []),
      { name: video.title, path }
    ])
  });
};

exports.categoriesIndex = (req, res) => {
  const categories = Category.all();
  res.render('categories', {
    seo: buildSeo({
      title: `Browse Categories | ${config.siteName}`,
      description: 'Browse all video categories.',
      path: '/categories'
    }),
    categories
  });
};

exports.categoryShow = (req, res, next) => {
  const category = Category.findBySlug(req.params.slug);
  if (!category) return next();

  const page = parseInt(req.query.page, 10) || 1;
  const sort = req.query.sort || 'newest';
  const result = Video.list({ categorySlug: category.slug, sort, page, perPage: 12 });

  res.render('category', {
    seo: buildSeo({
      title: `${category.name} Videos | ${config.siteName}`,
      description: category.description || `Browse ${category.name} videos.`,
      path: `/category/${category.slug}`
    }),
    category,
    sort,
    result,
    baseUrl: `/category/${category.slug}`,
    buildPageQuery: makePageQueryBuilder(req.query)
  });
};
