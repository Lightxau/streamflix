const config = require('../config/config');
const Video = require('../models/Video');
const { buildSeo } = require('../utils/seo');
const { makePageQueryBuilder } = require('../utils/pagination');

exports.searchPage = (req, res) => {
  const q = (req.query.q || '').trim();
  const page = parseInt(req.query.page, 10) || 1;
  const sort = req.query.sort || 'newest';

  const result = q ? Video.list({ q, sort, page, perPage: 12 }) : { rows: [], total: 0, page: 1, perPage: 12, totalPages: 1 };

  res.render('search', {
    seo: buildSeo({
      title: q ? `Search results for "${q}" | ${config.siteName}` : `Search | ${config.siteName}`,
      description: q ? `Search results for "${q}".` : 'Search videos by title, category, or tag.',
      path: `/search${q ? `/${encodeURIComponent(q)}` : ''}`,
      robots: 'noindex, follow'
    }),
    q,
    sort,
    result,
    baseUrl: '/search',
    buildPageQuery: makePageQueryBuilder(req.query)
  });
};

// GET /api/videos?category=slug&q=term&sort=newest&page=2&perPage=12
// Generic JSON listing endpoint backing the "Load More" / infinite scroll
// behavior on category and search pages (see public/js/infinite-scroll.js).
// Deliberately mirrors the same Video.list() call the server-rendered pages
// use, so page 1 rendered by EJS and page 2+ appended by JS always agree.
exports.videosApi = (req, res) => {
  const page = parseInt(req.query.page, 10) || 1;
  const sort = req.query.sort || 'newest';
  const categorySlug = req.query.category || null;
  const q = (req.query.q || '').trim() || null;

  if (!categorySlug && !q) return res.json({ rows: [], page: 1, totalPages: 1 });

  const result = Video.list({ categorySlug, q, sort, page, perPage: 12 });
  res.json({
    rows: result.rows.map((v) => ({
      title: v.title,
      slug: v.slug,
      thumbnail: v.thumbnail,
      thumbnail_srcset: v.thumbnail_srcset,
      duration: v.duration,
      views: v.views,
      featured: v.featured,
      category_name: v.category_name
    })),
    page: result.page,
    totalPages: result.totalPages
  });
};
exports.suggestions = (req, res) => {
  const q = (req.query.q || '').trim();
  if (q.length < 2) return res.json({ results: [] });
  const results = Video.suggest(q, 6).map((v) => ({
    title: v.title,
    slug: v.slug,
    thumbnail: v.thumbnail,
    category: v.category_name
  }));
  res.json({ results });
};
