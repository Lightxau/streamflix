const bcrypt = require('bcrypt');
const config = require('../config/config');
const User = require('../models/User');
const { buildSeo } = require('../utils/seo');
const { loginValidationRules, validationResult } = require('../middleware/validation');

exports.showLogin = (req, res) => {
  res.render('login', {
    seo: buildSeo({
      title: `Admin Login | ${config.siteName}`,
      description: 'Sign in to the admin dashboard.',
      path: '/login',
      robots: 'noindex'
    }),
    error: null
  });
};

exports.validators = loginValidationRules;

exports.handleLogin = (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).render('login', {
      seo: buildSeo({ title: `Admin Login | ${config.siteName}`, description: '', path: '/login', robots: 'noindex' }),
      error: 'Please enter both a username and password.'
    });
  }

  const { username, password } = req.body;
  const user = User.findByUsername(username);

  // Compare against a dummy hash even when the user doesn't exist, so
  // response timing doesn't leak whether a username is valid.
  const hashToCheck = user ? user.password_hash : '$2b$12$invalidsaltinvalidsaltinvalidsaltinvalidsal';
  const passwordMatches = bcrypt.compareSync(password, hashToCheck);

  if (!user || !passwordMatches) {
    return res.status(401).render('login', {
      seo: buildSeo({ title: `Admin Login | ${config.siteName}`, description: '', path: '/login', robots: 'noindex' }),
      error: 'Invalid username or password.'
    });
  }

  req.session.regenerate((err) => {
    if (err) return res.status(500).render('error', { seo: {}, message: 'Login failed. Please try again.' });
    req.session.user = { id: user.id, username: user.username, role: user.role };
    const returnTo = req.session.returnTo || '/admin';
    delete req.session.returnTo;
    res.redirect(returnTo);
  });
};

exports.handleLogout = (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('connect.sid');
    res.redirect('/login');
  });
};
