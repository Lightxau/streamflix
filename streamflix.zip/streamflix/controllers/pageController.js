const config = require('../config/config');
const { buildSeo } = require('../utils/seo');

exports.about = (req, res) => {
  res.render('about', {
    seo: buildSeo({
      title: `About Us | ${config.siteName}`,
      description: `Learn about ${config.siteName}, a curated video streaming platform.`,
      path: '/about'
    })
  });
};

exports.contact = (req, res) => {
  res.render('contact', {
    seo: buildSeo({
      title: `Contact Us | ${config.siteName}`,
      description: `Get in touch with the ${config.siteName} team.`,
      path: '/contact'
    }),
    sent: req.query.sent === '1'
  });
};

exports.contactSubmit = (req, res) => {
  // In production this would send an email or store a support ticket.
  // Kept intentionally simple and dependency-free for this starter project.
  res.redirect('/contact?sent=1');
};

exports.privacy = (req, res) => {
  res.render('privacy', {
    seo: buildSeo({
      title: `Privacy Policy | ${config.siteName}`,
      description: `Read the ${config.siteName} privacy policy.`,
      path: '/privacy-policy'
    })
  });
};

exports.terms = (req, res) => {
  res.render('terms', {
    seo: buildSeo({
      title: `Terms of Service | ${config.siteName}`,
      description: `Read the ${config.siteName} terms of service.`,
      path: '/terms-of-service'
    })
  });
};

exports.dmca = (req, res) => {
  res.render('dmca', {
    seo: buildSeo({
      title: `DMCA / Content Removal Policy | ${config.siteName}`,
      description: `How to submit a content removal or DMCA request to ${config.siteName}.`,
      path: '/dmca'
    })
  });
};
