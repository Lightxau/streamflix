// Protects admin routes. Relies on express-session storing { user: {...} }.
function requireAuth(req, res, next) {
  if (req.session && req.session.user) {
    return next();
  }
  req.session.returnTo = req.originalUrl;
  return res.redirect('/login');
}

// Redirects an already-logged-in admin away from the login page
function redirectIfAuthed(req, res, next) {
  if (req.session && req.session.user) {
    return res.redirect('/admin');
  }
  return next();
}

module.exports = { requireAuth, redirectIfAuthed };
