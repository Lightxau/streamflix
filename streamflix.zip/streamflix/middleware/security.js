const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const config = require('../config/config');

// Content Security Policy tuned to allow the embedded video iframes and
// Google Fonts, while blocking inline script execution from anywhere else.
const helmetMiddleware = helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", 'https://fonts.googleapis.com', "'unsafe-inline'"],
      fontSrc: ["'self'", 'https://fonts.gstatic.com'],
      imgSrc: ["'self'", 'data:', 'https:'],
      frameSrc: ['https://www.youtube.com', 'https://player.vimeo.com', 'https:'],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      upgradeInsecureRequests: []
    }
  },
  crossOriginEmbedderPolicy: false,
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
  // Only send HSTS over an actual HTTPS deployment — sending it in local
  // dev over plain http is a no-op in browsers but pointless noise either way.
  hsts: config.env === 'production' ? { maxAge: 15552000, includeSubDomains: true } : false
});

// Disables browser features this site never uses, reducing attack surface
// (e.g. a compromised third-party script couldn't request the camera).
const permissionsPolicy = (req, res, next) => {
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
  next();
};

// General rate limiter for the whole site
const generalLimiter = rateLimit({
  windowMs: config.rateLimitWindowMs,
  max: config.rateLimitMax,
  standardHeaders: true,
  legacyHeaders: false,
  message: 'Too many requests. Please try again shortly.'
});

// Tighter limiter specifically for the login endpoint to slow brute force
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: 'Too many login attempts. Please try again in 15 minutes.'
});

module.exports = { helmetMiddleware, generalLimiter, loginLimiter, permissionsPolicy };
