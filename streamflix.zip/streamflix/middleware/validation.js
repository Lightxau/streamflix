const { body, validationResult } = require('express-validator');

// Only allow embed URLs from platforms known to support embedding.
// Admins can extend this list in one place if they add a new permitted source.
const ALLOWED_EMBED_HOSTS = [
  'youtube.com',
  'www.youtube.com',
  'player.vimeo.com',
  'vimeo.com',
  'www.dailymotion.com',
  'embed.ted.com'
];

function isAllowedEmbedUrl(value) {
  try {
    const url = new URL(value);
    if (url.protocol !== 'https:') return false;
    return ALLOWED_EMBED_HOSTS.some((host) => url.hostname === host || url.hostname.endsWith(`.${host}`));
  } catch (e) {
    return false;
  }
}

const videoValidationRules = [
  body('title').trim().isLength({ min: 2, max: 200 }).withMessage('Title must be 2-200 characters.'),
  body('description').trim().isLength({ max: 5000 }).withMessage('Description is too long.'),
  body('embed_url')
    .trim()
    .isURL({ require_protocol: true })
    .withMessage('Please provide a valid URL.')
    .bail()
    .custom(isAllowedEmbedUrl)
    .withMessage('Embed URL must be from a platform that permits embedding (YouTube, Vimeo, Dailymotion, TED).'),
  body('duration').trim().isLength({ max: 20 }),
  body('category_id').optional({ checkFalsy: true }).isInt().withMessage('Invalid category.'),
  body('tags').trim().isLength({ max: 300 }),
  body('publish_date').optional({ checkFalsy: true }).isISO8601().withMessage('Invalid date.')
];

const categoryValidationRules = [
  body('name').trim().isLength({ min: 2, max: 80 }).withMessage('Name must be 2-80 characters.'),
  body('description').trim().isLength({ max: 500 })
];

const loginValidationRules = [
  body('username').trim().notEmpty().withMessage('Username is required.'),
  body('password').notEmpty().withMessage('Password is required.')
];

module.exports = {
  videoValidationRules,
  categoryValidationRules,
  loginValidationRules,
  validationResult,
  isAllowedEmbedUrl,
  ALLOWED_EMBED_HOSTS
};
