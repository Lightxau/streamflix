const config = require('../config/config');
const { logError } = require('../utils/logger');

function notFoundHandler(req, res) {
  res.status(404).render('404', {
    seo: {
      title: `Page Not Found | ${config.siteName}`,
      description: 'The page you are looking for could not be found.',
      canonical: `${config.siteUrl}${req.originalUrl}`,
      robots: 'noindex'
    }
  });
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  logError(err, { method: req.method, url: req.originalUrl });

  if (err && err.code === 'EBADCSRFTOKEN') {
    return res.status(403).render('error', {
      seo: { title: `Form Expired | ${config.siteName}`, description: '', canonical: '', robots: 'noindex' },
      message: 'Your form session expired or the request looked suspicious. Please go back and try again.'
    });
  }

  const status = err.status || 500;
  res.status(status).render('error', {
    seo: { title: `Something Went Wrong | ${config.siteName}`, description: '', canonical: '', robots: 'noindex' },
    message: config.env === 'development' ? err.message : 'Something went wrong on our end. Please try again shortly.'
  });
}

module.exports = { notFoundHandler, errorHandler };
