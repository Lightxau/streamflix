// PM2 process configuration.
// Start with:  pm2 start ecosystem.config.js --env production
// Persist across reboots:  pm2 save && pm2 startup
module.exports = {
  apps: [
    {
      name: 'streamflix',
      script: 'server.js',
      instances: 1, // SQLite via better-sqlite3 is a single-file, single-writer database —
                    // do not scale this to cluster mode without moving to a networked DB first.
      exec_mode: 'fork',
      autorestart: true,
      watch: false,
      max_memory_restart: '300M',
      env: {
        NODE_ENV: 'development'
      },
      env_production: {
        NODE_ENV: 'production'
      },
      error_file: 'logs/pm2-error.log',
      out_file: 'logs/pm2-out.log',
      time: true
    }
  ]
};
