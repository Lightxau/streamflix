const db = require('../config/database');

const Setting = {
  all() {
    const rows = db.prepare('SELECT key, value FROM settings').all();
    return rows.reduce((acc, r) => ({ ...acc, [r.key]: r.value }), {});
  },
  get(key, fallback = '') {
    const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
    return row ? row.value : fallback;
  },
  set(key, value) {
    db.prepare(`
      INSERT INTO settings (key, value) VALUES (?, ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value
    `).run(key, value);
  }
};

module.exports = Setting;
