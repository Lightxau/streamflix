const db = require('../config/database');
const slugify = require('slugify');

const BASE_SELECT = `
  SELECT v.*, c.name AS category_name, c.slug AS category_slug
  FROM videos v
  LEFT JOIN categories c ON c.id = v.category_id
`;

// A video is visible to normal (non-admin) visitors only once it's
// `published` AND its publish_date has arrived. This is what makes
// "draft" and "scheduled publishing" work — see create()/update() below
// for exactly how draft vs scheduled vs published map onto (status, publish_date).
const PUBLIC_VISIBLE_SQL = "v.status = 'published' AND v.publish_date <= date('now')";

function uniqueSlug(title, ignoreId = null) {
  const base = slugify(title, { lower: true, strict: true });
  let slug = base;
  let n = 1;
  // Guarantee uniqueness for SEO-friendly URLs like /video/my-video-title
  while (true) {
    const row = db.prepare('SELECT id FROM videos WHERE slug = ?').get(slug);
    if (!row || row.id === ignoreId) break;
    n += 1;
    slug = `${base}-${n}`;
  }
  return slug;
}

const Video = {
  // `includeUnpublished` is only ever passed `true` from admin code paths
  // (see controllers/adminController.js), so public routes are unaffected.
  findBySlug(slug, { includeUnpublished = false } = {}) {
    const visibility = includeUnpublished ? '' : `AND ${PUBLIC_VISIBLE_SQL}`;
    return db.prepare(`${BASE_SELECT} WHERE v.slug = ? ${visibility}`).get(slug);
  },

  // Used by the admin dashboard, which must be able to load drafts too.
  findById(id) {
    return db.prepare(`${BASE_SELECT} WHERE v.id = ?`).get(id);
  },

  // Increments the lifetime counter (cheap, used everywhere for a "views"
  // display) AND logs a timestamped event so analytics can compute
  // daily/weekly/monthly breakdowns and a recency-aware trending score.
  incrementViews(id) {
    const tx = db.transaction((videoId) => {
      db.prepare('UPDATE videos SET views = views + 1 WHERE id = ?').run(videoId);
      db.prepare('INSERT INTO video_view_events (video_id) VALUES (?)').run(videoId);
    });
    tx(id);
  },

  featured(limit = 8) {
    return db.prepare(`${BASE_SELECT} WHERE v.featured = 1 AND ${PUBLIC_VISIBLE_SQL} ORDER BY v.created_at DESC LIMIT ?`).all(limit);
  },

  // Recency-weighted trending: a video's score decays as it ages, so a video
  // with fewer total views but a recent burst of activity can still surface
  // above an old video that racked up views a year ago. Falls back to
  // lifetime views for installs that don't have event history yet (e.g.
  // right after upgrading from the previous version of this app).
  trending(limit = 12) {
    const hasEvents = db.prepare('SELECT COUNT(*) AS n FROM video_view_events').get().n > 0;
    if (!hasEvents) {
      return db.prepare(`${BASE_SELECT} WHERE ${PUBLIC_VISIBLE_SQL} ORDER BY v.views DESC LIMIT ?`).all(limit);
    }
    return db.prepare(`
      SELECT v.*, c.name AS category_name, c.slug AS category_slug,
        SUM(1.0 / (1 + (julianday('now') - julianday(e.created_at)))) AS trend_score
      FROM videos v
      JOIN video_view_events e ON e.video_id = v.id
      LEFT JOIN categories c ON c.id = v.category_id
      WHERE ${PUBLIC_VISIBLE_SQL}
      GROUP BY v.id
      ORDER BY trend_score DESC
      LIMIT ?
    `).all(limit);
  },

  // "Popular This Week" — purely last-7-days view volume, distinct from the
  // decayed all-time trending score above.
  popularThisWeek(limit = 12) {
    return db.prepare(`
      SELECT v.*, c.name AS category_name, c.slug AS category_slug,
        COUNT(e.id) AS week_views
      FROM videos v
      JOIN video_view_events e ON e.video_id = v.id AND e.created_at >= datetime('now', '-7 days')
      LEFT JOIN categories c ON c.id = v.category_id
      WHERE ${PUBLIC_VISIBLE_SQL}
      GROUP BY v.id
      ORDER BY week_views DESC
      LIMIT ?
    `).all(limit);
  },

  recent(limit = 12) {
    return db.prepare(`${BASE_SELECT} WHERE ${PUBLIC_VISIBLE_SQL} ORDER BY v.publish_date DESC, v.created_at DESC LIMIT ?`).all(limit);
  },

  // Related videos now score by tag overlap first (more relevant than "same
  // category" alone), falling back to same-category, then to trending, so a
  // video with unique tags still gets sensible recommendations.
  related(video, limit = 8) {
    const tags = (video.tags || '').split(',').map((t) => t.trim()).filter(Boolean);
    if (tags.length) {
      const tagConditions = tags.map((_, i) => `(',' || v.tags || ',') LIKE @tag${i}`).join(' OR ');
      const params = { id: video.id, limit };
      tags.forEach((t, i) => { params[`tag${i}`] = `%,${t},%`; });
      const scored = db.prepare(`
        SELECT v.*, c.name AS category_name, c.slug AS category_slug,
          (${tags.map((_, i) => `(CASE WHEN (',' || v.tags || ',') LIKE @tag${i} THEN 1 ELSE 0 END)`).join(' + ')}) AS tag_matches,
          (CASE WHEN v.category_id IS @categoryId THEN 1 ELSE 0 END) AS same_category
        FROM videos v
        LEFT JOIN categories c ON c.id = v.category_id
        WHERE v.id != @id AND ${PUBLIC_VISIBLE_SQL} AND (${tagConditions} OR v.category_id IS @categoryId)
        ORDER BY tag_matches DESC, same_category DESC, v.views DESC
        LIMIT @limit
      `).all({ ...params, categoryId: video.category_id });
      if (scored.length >= limit) return scored;
      // Not enough tag/category matches — top up with generally trending videos.
      const existingIds = new Set([video.id, ...scored.map((v) => v.id)]);
      const filler = this.trending(limit).filter((v) => !existingIds.has(v.id));
      return [...scored, ...filler].slice(0, limit);
    }
    return db.prepare(`
      ${BASE_SELECT}
      WHERE v.id != ? AND v.category_id IS ? AND ${PUBLIC_VISIBLE_SQL}
      ORDER BY v.views DESC LIMIT ?
    `).all(video.id, video.category_id, limit);
  },

  // Generic paginated + filterable + sortable listing used by category pages,
  // search results, and the admin video table.
  //
  // `visibility`:
  //   'public' (default) — only published, already-live videos. Used by every
  //     visitor-facing controller, so drafts/scheduled videos never leak out.
  //   'all' — every status. Used only by the admin dashboard.
  list({ categorySlug = null, q = null, tag = null, status = null, sort = 'newest', page = 1, perPage = 12, visibility = 'public' } = {}) {
    const where = [];
    const params = {};

    if (visibility === 'public') {
      where.push(PUBLIC_VISIBLE_SQL);
    } else if (status) {
      where.push('v.status = @status');
      params.status = status;
    }
    if (categorySlug) {
      where.push('c.slug = @categorySlug');
      params.categorySlug = categorySlug;
    }
    if (tag) {
      where.push("(',' || v.tags || ',') LIKE @tag");
      params.tag = `%,${tag},%`;
    }
    if (q) {
      where.push('(v.title LIKE @q OR v.description LIKE @q OR v.tags LIKE @q OR c.name LIKE @q)');
      params.q = `%${q}%`;
    }

    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';

    const sortMap = {
      newest: 'v.publish_date DESC, v.created_at DESC',
      oldest: 'v.publish_date ASC, v.created_at ASC',
      popular: 'v.views DESC',
      title_az: 'v.title ASC',
      title_za: 'v.title DESC'
    };
    const orderSql = sortMap[sort] || sortMap.newest;

    const totalRow = db.prepare(`
      SELECT COUNT(*) AS total FROM videos v LEFT JOIN categories c ON c.id = v.category_id ${whereSql}
    `).get(params);
    const total = totalRow ? totalRow.total : 0;

    const safePerPage = Math.min(Math.max(parseInt(perPage, 10) || 12, 1), 48);
    const totalPages = Math.max(Math.ceil(total / safePerPage), 1);
    const safePage = Math.min(Math.max(parseInt(page, 10) || 1, 1), totalPages);
    const offset = (safePage - 1) * safePerPage;

    const rows = db.prepare(`
      ${BASE_SELECT}
      ${whereSql}
      ORDER BY ${orderSql}
      LIMIT @limit OFFSET @offset
    `).all({ ...params, limit: safePerPage, offset });

    return { rows, total, page: safePage, perPage: safePerPage, totalPages };
  },

  // Lightweight suggestion list for the instant search dropdown
  suggest(q, limit = 6) {
    if (!q) return [];
    return db.prepare(`
      ${BASE_SELECT}
      WHERE (v.title LIKE @q OR v.tags LIKE @q OR c.name LIKE @q) AND ${PUBLIC_VISIBLE_SQL}
      ORDER BY v.views DESC
      LIMIT ?
    `).all({ q: `%${q}%` }, limit);
  },

  allForAdmin({ page = 1, perPage = 15, q = null, status = null, sort = 'newest' } = {}) {
    return this.list({ page, perPage, sort, q, status, visibility: 'all' });
  },

  // `status` is one of 'draft' | 'published' | 'scheduled'. Scheduling is
  // just a published-in-the-future video: the PUBLIC_VISIBLE_SQL guard above
  // already hides anything whose publish_date hasn't arrived, so a
  // "scheduled" video is stored with status='published' and a future date —
  // admin screens still label it "Scheduled" based on that combination (see
  // adminController.js `describeStatus`).
  create(data) {
    const slug = uniqueSlug(data.title);
    const info = db.prepare(`
      INSERT INTO videos
        (title, slug, description, embed_url, thumbnail, thumbnail_srcset, duration, category_id, tags, featured, status, meta_title, meta_description, publish_date)
      VALUES (@title, @slug, @description, @embed_url, @thumbnail, @thumbnail_srcset, @duration, @category_id, @tags, @featured, @status, @meta_title, @meta_description, @publish_date)
    `).run({ thumbnail_srcset: '', status: 'published', ...data, slug });
    return this.findById(info.lastInsertRowid);
  },

  update(id, data) {
    const current = this.findById(id);
    if (!current) return null;
    const slug = data.title && data.title !== current.title ? uniqueSlug(data.title, id) : current.slug;
    db.prepare(`
      UPDATE videos SET
        title = @title, slug = @slug, description = @description, embed_url = @embed_url,
        thumbnail = @thumbnail, thumbnail_srcset = @thumbnail_srcset, duration = @duration,
        category_id = @category_id, tags = @tags, featured = @featured, status = @status,
        meta_title = @meta_title, meta_description = @meta_description,
        publish_date = @publish_date, updated_at = datetime('now')
      WHERE id = @id
    `).run({ thumbnail_srcset: current.thumbnail_srcset || '', status: current.status, ...data, slug, id });
    return this.findById(id);
  },

  delete(id) {
    db.prepare('DELETE FROM videos WHERE id = ?').run(id);
  },

  // ----- Bulk admin operations -----
  bulkDelete(ids) {
    if (!ids.length) return 0;
    const placeholders = ids.map(() => '?').join(',');
    return db.prepare(`DELETE FROM videos WHERE id IN (${placeholders})`).run(...ids).changes;
  },
  bulkSetCategory(ids, categoryId) {
    if (!ids.length) return 0;
    const placeholders = ids.map(() => '?').join(',');
    return db.prepare(`UPDATE videos SET category_id = ?, updated_at = datetime('now') WHERE id IN (${placeholders})`)
      .run(categoryId || null, ...ids).changes;
  },
  bulkSetStatus(ids, status) {
    if (!ids.length) return 0;
    const placeholders = ids.map(() => '?').join(',');
    return db.prepare(`UPDATE videos SET status = ?, updated_at = datetime('now') WHERE id IN (${placeholders})`)
      .run(status, ...ids).changes;
  },
  bulkSetFeatured(ids, featured) {
    if (!ids.length) return 0;
    const placeholders = ids.map(() => '?').join(',');
    return db.prepare(`UPDATE videos SET featured = ?, updated_at = datetime('now') WHERE id IN (${placeholders})`)
      .run(featured ? 1 : 0, ...ids).changes;
  },

  counts() {
    return db.prepare(`
      SELECT
        COUNT(*) AS total,
        SUM(views) AS views,
        SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) AS drafts,
        SUM(CASE WHEN status = 'published' AND publish_date > date('now') THEN 1 ELSE 0 END) AS scheduled,
        SUM(CASE WHEN status = 'published' AND publish_date <= date('now') THEN 1 ELSE 0 END) AS published
      FROM videos
    `).get();
  },

  topByViews(limit = 5) {
    return db.prepare(`${BASE_SELECT} ORDER BY v.views DESC LIMIT ?`).all(limit);
  },

  recentlyUploaded(limit = 5) {
    return db.prepare(`${BASE_SELECT} ORDER BY v.created_at DESC LIMIT ?`).all(limit);
  },

  // ----- Analytics (used by the admin dashboard) -----

  // Views per day for the last N days, oldest first, zero-filled so charts
  // don't have gaps on days with no activity.
  dailyViews(days = 14) {
    const rows = db.prepare(`
      SELECT date(created_at) AS day, COUNT(*) AS views
      FROM video_view_events
      WHERE created_at >= datetime('now', ?)
      GROUP BY day
      ORDER BY day ASC
    `).all(`-${days} days`);
    return zeroFillDays(rows, days);
  },

  // Views bucketed by ISO week for the last N weeks.
  weeklyViews(weeks = 8) {
    return db.prepare(`
      SELECT strftime('%Y-W%W', created_at) AS week, COUNT(*) AS views
      FROM video_view_events
      WHERE created_at >= datetime('now', ?)
      GROUP BY week
      ORDER BY week ASC
    `).all(`-${weeks * 7} days`);
  },

  // Views bucketed by calendar month for the last N months.
  monthlyViews(months = 6) {
    return db.prepare(`
      SELECT strftime('%Y-%m', created_at) AS month, COUNT(*) AS views
      FROM video_view_events
      WHERE created_at >= datetime('now', ?)
      GROUP BY month
      ORDER BY month ASC
    `).all(`-${months * 31} days`);
  },

  topCategories(limit = 6) {
    return db.prepare(`
      SELECT c.id, c.name, c.slug, COUNT(v.id) AS video_count, COALESCE(SUM(v.views), 0) AS total_views
      FROM categories c
      LEFT JOIN videos v ON v.category_id = c.id
      GROUP BY c.id
      ORDER BY total_views DESC
      LIMIT ?
    `).all(limit);
  }
};

function zeroFillDays(rows, days) {
  const byDay = new Map(rows.map((r) => [r.day, r.views]));
  const out = [];
  for (let i = days - 1; i >= 0; i -= 1) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    out.push({ day: key, views: byDay.get(key) || 0 });
  }
  return out;
}

module.exports = Video;
