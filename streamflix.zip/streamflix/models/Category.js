const db = require('../config/database');
const slugify = require('slugify');

const Category = {
  all() {
    return db.prepare(`
      SELECT c.*, COUNT(v.id) AS video_count
      FROM categories c
      LEFT JOIN videos v ON v.category_id = c.id
      GROUP BY c.id
      ORDER BY c.name ASC
    `).all();
  },
  findBySlug(slug) {
    return db.prepare('SELECT * FROM categories WHERE slug = ?').get(slug);
  },
  findByName(name) {
    return db.prepare('SELECT * FROM categories WHERE name = ? COLLATE NOCASE').get(name);
  },
  findById(id) {
    return db.prepare('SELECT * FROM categories WHERE id = ?').get(id);
  },
  create({ name, description = '' }) {
    const slug = slugify(name, { lower: true, strict: true });
    const info = db.prepare(
      'INSERT INTO categories (name, slug, description) VALUES (?, ?, ?)'
    ).run(name, slug, description);
    return this.findById(info.lastInsertRowid);
  },
  update(id, { name, description }) {
    const slug = slugify(name, { lower: true, strict: true });
    db.prepare('UPDATE categories SET name = ?, slug = ?, description = ? WHERE id = ?')
      .run(name, slug, description, id);
  },
  delete(id) {
    db.prepare('DELETE FROM categories WHERE id = ?').run(id);
  }
};

module.exports = Category;
