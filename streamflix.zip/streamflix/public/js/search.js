// ---------------------------------------------------------------------------
// Instant search suggestions. Debounces keystrokes and fetches from
// GET /api/search-suggestions?q=... which returns lightweight JSON.
// ---------------------------------------------------------------------------
(function () {
  'use strict';

  const inputs = document.querySelectorAll('[data-search-input]');
  if (!inputs.length) return;

  let debounceTimer = null;

  inputs.forEach((input) => {
    const wrapper = input.closest('[data-search-wrapper]');
    const suggestBox = wrapper ? wrapper.querySelector('[data-search-suggest]') : null;
    if (!suggestBox) return;

    input.addEventListener('input', () => {
      const q = input.value.trim();
      clearTimeout(debounceTimer);
      if (q.length < 2) {
        suggestBox.classList.remove('open');
        suggestBox.innerHTML = '';
        return;
      }
      debounceTimer = setTimeout(() => fetchSuggestions(q, suggestBox), 220);
    });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') suggestBox.classList.remove('open');
    });

    document.addEventListener('click', (e) => {
      if (!wrapper.contains(e.target)) suggestBox.classList.remove('open');
    });
  });

  async function fetchSuggestions(q, box) {
    try {
      const res = await fetch(`/api/search-suggestions?q=${encodeURIComponent(q)}`);
      if (!res.ok) throw new Error('Search request failed');
      const data = await res.json();
      renderSuggestions(data.results || [], box, q);
    } catch (err) {
      box.classList.remove('open');
    }
  }

  function renderSuggestions(results, box, q) {
    if (!results.length) {
      box.innerHTML = `<div class="search-suggest__item"><span class="name">No matches for "${escapeHtml(q)}"</span></div>`;
      box.classList.add('open');
      return;
    }
    box.innerHTML = results.map((r) => `
      <a class="search-suggest__item" href="/video/${encodeURIComponent(r.slug)}">
        <img src="${escapeAttr(r.thumbnail || '/images/placeholder-thumb.svg')}" alt="" loading="lazy">
        <span>
          <span class="name">${escapeHtml(r.title)}</span><br>
          <span class="cat">${escapeHtml(r.category || '')}</span>
        </span>
      </a>
    `).join('');
    box.classList.add('open');
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }
  function escapeAttr(str) { return escapeHtml(str); }
})();
