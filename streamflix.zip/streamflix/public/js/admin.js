// ---------------------------------------------------------------------------
// Admin dashboard behaviors: image preview on file select, and a confirm
// step before any destructive delete action.
// ---------------------------------------------------------------------------
(function () {
  'use strict';

  const fileInput = document.querySelector('[data-thumbnail-input]');
  const preview = document.querySelector('[data-thumbnail-preview]');
  if (fileInput && preview) {
    fileInput.addEventListener('change', () => {
      const file = fileInput.files && fileInput.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (e) => { preview.src = e.target.result; preview.style.display = 'block'; };
      reader.readAsDataURL(file);
    });
  }

  document.querySelectorAll('form[data-confirm-delete]').forEach((form) => {
    form.addEventListener('submit', (e) => {
      // Only confirm when the button that triggered submission is itself
      // marked destructive (e.g. a "Delete" button sharing a form with "Save").
      const submitter = e.submitter;
      const isDestructive = submitter && (submitter.classList.contains('btn-danger') || submitter.hasAttribute('data-destructive'));
      if (!isDestructive) return;
      const label = form.getAttribute('data-confirm-delete') || 'this item';
      if (!window.confirm(`Delete ${label}? This cannot be undone.`)) {
        e.preventDefault();
      }
    });
  });

  // ----- Bulk video actions (select-all, live count, confirm before apply) -----
  const bulkForm = document.querySelector('[data-bulk-form]');
  if (bulkForm) {
    const selectAll = bulkForm.querySelector('[data-select-all]');
    const rowCheckboxes = () => Array.from(bulkForm.querySelectorAll('[data-row-checkbox]'));
    const countEl = bulkForm.querySelector('[data-bulk-selected-count]');

    function updateCount() {
      const checked = rowCheckboxes().filter((cb) => cb.checked).length;
      if (countEl) countEl.textContent = String(checked);
    }

    if (selectAll) {
      selectAll.addEventListener('change', () => {
        rowCheckboxes().forEach((cb) => { cb.checked = selectAll.checked; });
        updateCount();
      });
    }
    rowCheckboxes().forEach((cb) => cb.addEventListener('change', updateCount));
    updateCount();

    bulkForm.addEventListener('submit', (e) => {
      const checked = rowCheckboxes().filter((cb) => cb.checked);
      if (!checked.length) {
        e.preventDefault();
        window.alert('Select at least one video first.');
        return;
      }
      const action = bulkForm.querySelector('[name="bulk_action"]').value;
      const destructiveActions = new Set(['delete']);
      if (destructiveActions.has(action) && !window.confirm(`Apply "${action}" to ${checked.length} selected video(s)? This cannot be undone.`)) {
        e.preventDefault();
      }
    });
  }
})();
