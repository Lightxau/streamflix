// ---------------------------------------------------------------------------
// Single source of truth for rendering a video card as an HTML string on the
// client (mirrors views/partials/video-card.ejs). Used by history.js
// (Continue Watching / Favorites / History) and infinite-scroll.js (category
// & search "Load More"), so we don't maintain two slightly-different copies
// of the same markup.
// ---------------------------------------------------------------------------
(function () {
  'use strict';

  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function renderVideoCardHtml(v) {
    const duration = v.duration ? `<span class="stub">${escapeHtml(v.duration)}</span>` : '';
    const featured = v.featured ? '<span class="stub stub--featured">Featured</span>' : '';
    const cat = v.category_name ? `<span>${escapeHtml(v.category_name)}</span><span class="dot"></span>` : '';
    const srcset = v.thumbnail_srcset ? ` srcset="${escapeHtml(v.thumbnail_srcset)}" sizes="(max-width: 600px) 320px, 640px"` : '';
    return `
      <a class="card" href="/video/${encodeURIComponent(v.slug)}">
        <div class="card__thumb">
          <img src="${escapeHtml(v.thumbnail || '/images/placeholder-thumb.svg')}"${srcset} alt="${escapeHtml(v.title)} thumbnail" loading="lazy" width="640" height="360">
          ${featured}${duration}
        </div>
        <div class="card__body">
          <h3 class="card__title">${escapeHtml(v.title)}</h3>
          <div class="card__meta">${cat}<span>${Number(v.views || 0).toLocaleString()} views</span></div>
        </div>
      </a>`;
  }

  window.StreamFlixCards = { renderVideoCardHtml, escapeHtml };
})();
