// ---------------------------------------------------------------------------
// Video detail page interactions:
// - Like button uses localStorage only (no server persistence, as specced).
// - Share buttons open standard share intents / copy the link.
// ---------------------------------------------------------------------------
(function () {
  'use strict';

  const likeBtn = document.querySelector('[data-like-btn]');
  if (likeBtn) {
    const slug = likeBtn.getAttribute('data-video-slug');
    const storageKey = `streamflix:liked:${slug}`;
    const countEl = likeBtn.querySelector('[data-like-count]');
    let baseCount = parseInt(likeBtn.getAttribute('data-base-likes'), 10) || 0;
    let liked = localStorage.getItem(storageKey) === '1';

    function render() {
      likeBtn.classList.toggle('liked', liked);
      if (countEl) countEl.textContent = liked ? baseCount + 1 : baseCount;
      likeBtn.setAttribute('aria-pressed', String(liked));
    }
    render();

    likeBtn.addEventListener('click', () => {
      liked = !liked;
      localStorage.setItem(storageKey, liked ? '1' : '0');
      render();
    });
  }

  document.querySelectorAll('[data-share]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const url = window.location.href;
      const network = btn.getAttribute('data-share');
      if (network === 'copy') {
        try {
          await navigator.clipboard.writeText(url);
          if (window.showToast) window.showToast('Link copied to clipboard.');
        } catch (e) {
          if (window.showToast) window.showToast('Could not copy link.', 'error');
        }
        return;
      }
      const shareUrls = {
        twitter: `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}`,
        facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
        linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`
      };
      if (shareUrls[network]) window.open(shareUrls[network], '_blank', 'noopener,width=600,height=500');
    });
  });
})();
