// ---------------------------------------------------------------------------
// StreamFlix has no visitor accounts — only an admin login — so "Continue
// Watching", "Recently Watched", and "Favorites" are implemented entirely in
// the browser via localStorage, keyed per-device. There is no server-side
// per-user table, and nothing here is sent to the server except a read-only
// lookup of public video data for the slugs already in localStorage
// (GET /api/videos-by-slugs), used to turn saved slugs into real cards.
//
// Because videos play inside a cross-origin third-party iframe (YouTube,
// Vimeo, etc.), we cannot read real playback position — that information is
// simply not exposed across the iframe boundary. "Continue Watching" is
// therefore "recently opened", not a resumable timestamp. This is a
// deliberate, honest scope decision rather than an oversight.
// ---------------------------------------------------------------------------
(function () {
  'use strict';

  const HISTORY_KEY = 'streamflix:watchHistory';
  const FAVORITES_KEY = 'streamflix:favorites';
  const MAX_HISTORY = 30;

  function readList(key) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }
  function writeList(key, list) {
    try { localStorage.setItem(key, JSON.stringify(list)); } catch (e) { /* storage full/unavailable */ }
  }

  const History = {
    getSlugs() { return readList(HISTORY_KEY).map((e) => e.slug); },
    add(slug) {
      if (!slug) return;
      let list = readList(HISTORY_KEY).filter((e) => e.slug !== slug);
      list.unshift({ slug, watchedAt: new Date().toISOString() });
      list = list.slice(0, MAX_HISTORY);
      writeList(HISTORY_KEY, list);
    },
    clear() { writeList(HISTORY_KEY, []); }
  };

  const Favorites = {
    getSlugs() { return readList(FAVORITES_KEY).map((e) => e.slug); },
    has(slug) { return this.getSlugs().includes(slug); },
    toggle(slug) {
      const list = readList(FAVORITES_KEY);
      const idx = list.findIndex((e) => e.slug === slug);
      if (idx >= 0) {
        list.splice(idx, 1);
        writeList(FAVORITES_KEY, list);
        return false;
      }
      list.unshift({ slug, savedAt: new Date().toISOString() });
      writeList(FAVORITES_KEY, list);
      return true;
    }
  };

  window.StreamFlixHistory = History;
  window.StreamFlixFavorites = Favorites;

  // ----- Record a view + wire up the favorite button on video detail pages -----
  const videoPage = document.querySelector('[data-record-watch]');
  if (videoPage) {
    History.add(videoPage.getAttribute('data-record-watch'));
  }

  const favBtn = document.querySelector('[data-favorite-btn]');
  if (favBtn) {
    const slug = favBtn.getAttribute('data-video-slug');
    const render = () => {
      const active = Favorites.has(slug);
      favBtn.classList.toggle('liked', active);
      favBtn.setAttribute('aria-pressed', String(active));
      const label = favBtn.querySelector('[data-favorite-label]');
      if (label) label.textContent = active ? 'Saved' : 'Save';
    };
    render();
    favBtn.addEventListener('click', () => {
      Favorites.toggle(slug);
      render();
      if (window.showToast) window.showToast(Favorites.has(slug) ? 'Added to your favorites.' : 'Removed from your favorites.');
    });
  }

  // ----- Render a grid of cards from a list of slugs, via the hydration API -----
  async function hydrateAndRender(container, slugs, emptyMessage) {
    if (!container) return;
    if (!slugs.length) {
      if (emptyMessage) container.innerHTML = emptyMessage;
      return;
    }
    try {
      const res = await fetch(`/api/videos-by-slugs?slugs=${encodeURIComponent(slugs.join(','))}`);
      const data = await res.json();
      const results = data.results || [];
      if (!results.length) {
        if (emptyMessage) container.innerHTML = emptyMessage;
        return;
      }
      container.innerHTML = results.map((v) => window.StreamFlixCards.renderVideoCardHtml(v)).join('');
    } catch (e) {
      container.innerHTML = '<p style="color:var(--text-faint);">Could not load videos right now.</p>';
    }
  }

  // ----- Homepage "Continue Watching" rail -----
  const continueSection = document.querySelector('[data-continue-watching]');
  if (continueSection) {
    const grid = continueSection.querySelector('[data-continue-watching-grid]');
    const slugs = History.getSlugs().slice(0, 8);
    if (slugs.length) {
      continueSection.hidden = false;
      hydrateAndRender(grid, slugs, '');
    }
    const clearBtn = continueSection.querySelector('[data-clear-history]');
    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        History.clear();
        continueSection.hidden = true;
        if (window.showToast) window.showToast('Watch history cleared.');
      });
    }
  }

  // ----- Standalone /favorites and /history pages -----
  const favoritesGrid = document.querySelector('[data-favorites-grid]');
  if (favoritesGrid) {
    hydrateAndRender(
      favoritesGrid,
      Favorites.getSlugs(),
      '<div class="empty-state"><h2>No favorites yet</h2><p>Tap "Save" on any video to add it here.</p></div>'
    );
  }

  const historyGrid = document.querySelector('[data-history-grid]');
  if (historyGrid) {
    hydrateAndRender(
      historyGrid,
      History.getSlugs(),
      '<div class="empty-state"><h2>No watch history yet</h2><p>Videos you open will show up here.</p></div>'
    );
    const clearBtn = document.querySelector('[data-clear-history-page]');
    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        History.clear();
        historyGrid.innerHTML = '<div class="empty-state"><h2>No watch history yet</h2><p>Videos you open will show up here.</p></div>';
        if (window.showToast) window.showToast('Watch history cleared.');
      });
    }
  }
})();
