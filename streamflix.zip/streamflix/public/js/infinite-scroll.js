// ---------------------------------------------------------------------------
// Infinite scroll / "Load More" for category and search pages.
//
// Progressive enhancement: the page always renders working numbered
// pagination server-side first (so it works with JS disabled). If JS is
// available, this script hides that pagination and replaces it with a
// "Load More" button that appends additional pages into the same grid,
// falling back to an IntersectionObserver so it also loads automatically
// as the user nears the bottom of the list.
// ---------------------------------------------------------------------------
(function () {
  'use strict';

  const root = document.querySelector('[data-infinite-scroll]');
  if (!root) return;

  const grid = root.querySelector('[data-video-grid]');
  const pagination = root.querySelector('[data-pagination]');
  if (!grid || !pagination) return;

  let page = parseInt(root.getAttribute('data-current-page'), 10) || 1;
  const totalPages = parseInt(root.getAttribute('data-total-pages'), 10) || 1;
  const apiParams = root.getAttribute('data-api-params') || '';
  let loading = false;

  if (page >= totalPages) return; // nothing more to load — leave normal pagination visible

  pagination.hidden = true;

  const loadMoreBtn = document.createElement('button');
  loadMoreBtn.type = 'button';
  loadMoreBtn.className = 'btn btn-ghost btn-block';
  loadMoreBtn.style.marginTop = '32px';
  loadMoreBtn.textContent = 'Load More';
  root.appendChild(loadMoreBtn);

  const sentinel = document.createElement('div');
  sentinel.setAttribute('aria-hidden', 'true');
  root.appendChild(sentinel);

  async function loadNextPage() {
    if (loading || page >= totalPages) return;
    loading = true;
    loadMoreBtn.textContent = 'Loading…';
    loadMoreBtn.disabled = true;

    try {
      const nextPage = page + 1;
      const res = await fetch(`/api/videos?${apiParams}&page=${nextPage}`);
      const data = await res.json();
      const rows = data.rows || [];
      rows.forEach((v) => {
        grid.insertAdjacentHTML('beforeend', window.StreamFlixCards.renderVideoCardHtml(v));
      });
      page = data.page || nextPage;

      if (page >= (data.totalPages || totalPages)) {
        loadMoreBtn.remove();
        observer.disconnect();
      }
    } catch (e) {
      loadMoreBtn.textContent = 'Load More';
      if (window.showToast) window.showToast('Could not load more videos.', 'error');
    } finally {
      loading = false;
      loadMoreBtn.disabled = false;
      if (loadMoreBtn.isConnected) loadMoreBtn.textContent = 'Load More';
    }
  }

  loadMoreBtn.addEventListener('click', loadNextPage);

  const observer = new IntersectionObserver((entries) => {
    if (entries.some((e) => e.isIntersecting)) loadNextPage();
  }, { rootMargin: '400px' });
  observer.observe(sentinel);
})();
