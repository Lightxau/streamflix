// ---------------------------------------------------------------------------
// PWA bootstrap: registers the service worker and wires up a custom
// "Install App" button using the beforeinstallprompt event (Chrome/Edge/
// Android). Safari/iOS doesn't fire this event — installing there is via
// the native Share -> Add to Home Screen flow, which we can't trigger
// programmatically, so the button simply never appears there and that's fine.
// ---------------------------------------------------------------------------
(function () {
  'use strict';

  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js').catch((err) => {
        console.warn('Service worker registration failed:', err);
      });
    });
  }

  let deferredPrompt = null;
  const installBtn = document.querySelector('[data-install-app]');

  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    deferredPrompt = event;
    if (installBtn) installBtn.hidden = false;
  });

  if (installBtn) {
    installBtn.addEventListener('click', async () => {
      if (!deferredPrompt) return;
      deferredPrompt.prompt();
      await deferredPrompt.userChoice;
      deferredPrompt = null;
      installBtn.hidden = true;
    });
  }

  window.addEventListener('appinstalled', () => {
    if (installBtn) installBtn.hidden = true;
    if (window.showToast) window.showToast('StreamFlix installed. You can launch it from your home screen.');
  });
})();
