// StreamFlix service worker.
//
// Scope is deliberately modest: this is a video *discovery* site where the
// actual video playback happens in a cross-origin third-party iframe that
// a service worker can't (and shouldn't) try to cache. What we *can*
// usefully do offline is: serve the app shell (CSS/JS/fonts/icons) from
// cache instantly, and show a friendly offline page instead of the browser's
// default error when a visitor navigates to a page with no connection.
//
// Bump CACHE_VERSION whenever public/css or public/js changes materially,
// so returning visitors pick up the new files instead of stale cached ones.
const CACHE_VERSION = 'streamflix-v1';
const APP_SHELL = [
  '/css/style.css',
  '/js/main.js',
  '/js/cards.js',
  '/js/search.js',
  '/js/history.js',
  '/js/infinite-scroll.js',
  '/js/video.js',
  '/js/admin.js',
  '/images/placeholder-thumb.svg',
  '/images/og-default.svg',
  '/offline.html'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) => cache.addAll(APP_SHELL)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Never intercept admin, auth, or API requests — these must always hit
  // the network so session state, CSRF tokens, and analytics stay correct.
  if (url.pathname.startsWith('/admin') || url.pathname.startsWith('/api/') ||
      url.pathname === '/login' || url.pathname === '/logout') {
    return;
  }

  // Page navigations: try the network first (content changes often), and
  // fall back to the cached offline page if the network is unavailable.
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request).catch(() => caches.match('/offline.html'))
    );
    return;
  }

  // Static assets (CSS/JS/images/fonts): cache-first for speed, updating the
  // cache in the background when a fresh copy is fetched.
  if (['style', 'script', 'image', 'font'].includes(request.destination)) {
    event.respondWith(
      caches.match(request).then((cached) => {
        const networkFetch = fetch(request).then((response) => {
          if (response && response.ok) {
            caches.open(CACHE_VERSION).then((cache) => cache.put(request, response.clone()));
          }
          return response;
        }).catch(() => cached);
        return cached || networkFetch;
      })
    );
  }
});
